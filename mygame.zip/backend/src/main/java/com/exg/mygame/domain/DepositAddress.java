package com.exg.mygame.domain;

import java.time.Instant;
import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A customer's own address on a chain, derived from the bank's deposit seed
/// at BIP-44 path m/44'/60'/0'/0/`hdIndex`, so a standard wallet can recover
/// every one of them from the seed alone. Stored, not re-derived on every
/// scan: the scanner only needs to know whose an address is.
@Entity
public class DepositAddress {
    /// Lowercase, 0x-prefixed.
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(42)")
    private String address = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String owner = "";

    @Column(nullable = false, type = "VARCHAR(12)")
    private String asset = "";

    @Column(nullable = false)
    private long hdIndex;

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    public DepositAddress() {
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getAsset() {
        return asset;
    }

    public void setAsset(String asset) {
        this.asset = asset;
    }

    public long getHdIndex() {
        return hdIndex;
    }

    public void setHdIndex(long hdIndex) {
        this.hdIndex = hdIndex;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}

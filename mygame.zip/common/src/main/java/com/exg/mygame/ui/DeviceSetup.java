package com.exg.mygame.ui;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.exg.mygame.api.DeviceDto;
import com.exg.mygame.api.UserDto;
import com.exg.mygame.net.Net;
import com.exg.mygame.net.Session;
import com.exg.mygame.security.DeviceKey;

/// Registering this phone's signing key, from wherever it is asked for:
/// onboarding, the dashboard's banner, and a payment the server refused for
/// want of a signature.
///
/// The server asks for two things before it trusts a new key: a sign-in a
/// few minutes old, and a second factor used in that sign-in -- an
/// authenticator code or a passkey -- since a stolen session and password
/// must not be able to add the device that then signs payments. A sign-in
/// made with the password alone is sent to Settings to set one up instead of
/// being refused by the server with nothing to do about it.
public final class DeviceSetup {
    private DeviceSetup() {
    }

    /// Whether this phone can sign payments for the signed-in account (a
    /// key registered for another account does not count).
    public static boolean registered() {
        return DeviceKey.deviceId() != null && DeviceKey.ownedBy(Session.username());
    }

    /// Registers the device, asking for the password first when the account
    /// needs it. `failed` is not called when the user cancels.
    public static void register(final Runnable done, final Net.Failed failed) {
        UserDto user = Session.user();
        if (user == null) {
            failed.failed(401, "Sign in first");
            return;
        }
        String password = null;
        if (!Session.signedInWith("mfa") && !Session.signedInWith("otp")
                && !Session.signedInWith("hwk")) {
            secondFactorFirst();
            return;
        }
        // The same rule as Devices on the server, which reads the token's own
        // record of the sign-in, never whether an app is on the account now: a
        // code sign-in (`otp`/`mfa`) or a user-verified passkey (`hwk` with
        // `user`) is not asked for the password; a passkey the authenticator
        // did not verify the user for (`hwk` alone) is.
        if (!Session.signedInWith("mfa") && !Session.signedInWith("otp")
                && !(Session.signedInWith("hwk") && Session.signedInWith("user"))) {
            TextField field = new TextField("", Lang.tr("Password"), 20, TextArea.PASSWORD);
            field.setUIID("BnField");
            Command ok = new Command(Lang.tr("Continue"));
            if (Dialog.show(Lang.tr("Confirm it is you"),
                    // Enclosed, or the dialog stretches the one-line field to its
                    // whole body.
                    com.codename1.ui.layouts.BoxLayout.encloseY(field), ok,
                    new Command(Lang.tr("Cancel"))) != ok) {
                return;
            }
            password = field.getText();
        }
        DeviceKey.register(user.username(), password, (DeviceDto device) -> done.run(),
                (status, message) -> {
                    if ("second-factor-add-device".equals(Net.refusalCode())) {
                        secondFactorFirst();
                    } else {
                        failed.failed(status, message);
                    }
                });
    }

    /// The server's answer to a password-only sign-in, said before asking it:
    /// set up an authenticator app or a passkey, then sign in with it.
    private static void secondFactorFirst() {
        if (Dialog.show(Lang.tr("Set up a second factor"),
                Lang.tr("Adding a device that signs payments needs a sign-in with an "
                        + "authenticator app or a passkey. Set one up in Settings, then sign "
                        + "in with it and register this device."),
                Lang.tr("Open Settings"), Lang.tr("Not now"))) {
            SettingsForm.show(null);
        }
    }

    /// A refusal that a registered device would have avoided, as the server
    /// words it: no signature, or one from a device it does not know.
    public static boolean needsDevice(int status, String message) {
        String code = Net.refusalCode();
        return status == 403 && ("needs-device-signature".equals(code)
                || "device-not-attested".equals(code));
    }

    /// After such a refusal: offers to register this device, and runs
    /// `retry` once it is.
    public static void offer(final Runnable retry, final Net.Failed failed) {
        if (registered()) {
            // A registered device that is still refused is untrusted (rooted,
            // or not attested); registering again would not change that.
            return;
        }
        if (Dialog.show(Lang.tr("Sign with this device"),
                Lang.tr("Payments leaving your accounts are signed by a key that never leaves "
                        + "this phone. Register this device to continue."),
                Lang.tr("Register"), Lang.tr("Not now"))) {
            register(retry, failed);
        }
    }

    /// One try of a signed action. It signs afresh each time it runs -- a
    /// signature's nonce is good once -- and reports a refusal to `failed`.
    public interface Attempt {
        void send(Net.Failed failed);
    }

    /// Runs `attempt`; when the server refuses it for want of this device's
    /// signature, offers to register the device and tries once more. Any
    /// other refusal, or the second one, goes to `shown`.
    public static void withDevice(final Attempt attempt, final Net.Failed shown) {
        attempt.send((status, message) -> {
            if (needsDevice(status, message) && !registered()) {
                offer(() -> attempt.send(shown), shown);
            } else {
                shown.failed(status, message);
            }
        });
    }
}

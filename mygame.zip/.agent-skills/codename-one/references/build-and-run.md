# Build and Run Reference

## Local builds vs cloud builds

> **Maven or Gradle?** A project with `settings.gradle.kts` + `gradlew` and no `pom.xml` is a Gradle project: the app lives at the root instead of in `common/`, and every command below is a `./gradlew` task (see the "Gradle task" column and the Gradle cheat sheet). Everything else in this file applies to both.

A Codename One project can produce four kinds of artifacts. Some build entirely on your machine; others rely on the Codename One **build server** (cloud) because cross-compiling iOS/Android natively on every developer's box would be unrealistic.

| Output | Where it builds | Maven goal | Gradle task |
| --- | --- | --- | --- |
| Desktop simulator | Local (your machine, JVM only) | `mvn -pl common cn1:run` / `cn1:debug` | `./gradlew run` / `debug` |
| Unit tests | Local (the CN1 test runner inside a JVM) | `mvn -pl common cn1:test` | `./gradlew cn1Test` |
| Standalone desktop app (`.jar` + bundled JRE for Mac/Win/Linux) | Cloud (build server packages a JRE for each OS) | `mvn package -Dcodename1.platform=javase -Dcodename1.buildTarget=mac-os-x-desktop` (or `windows-desktop`, `linux-desktop`) | `./gradlew buildMacDesktop` / `buildWindowsDesktop` |
| Android APK / AAB | Cloud by default; **also** locally if you run `cn1:install-android-sdk` and use the local Android build path | `mvn package -Dcodename1.platform=android -Dcodename1.buildTarget=android-device` | `./gradlew buildAndroid` (local project: `buildAndroidGradleProject`) |
| iOS app | Cloud, **or** locally as an Xcode project via `ios-source` | `mvn package -Dcodename1.platform=ios -Dcodename1.buildTarget=ios-device` (cloud) or `…-Dcodename1.buildTarget=ios-source` (local Xcode project) | `./gradlew buildIos` / `buildIosRelease` (local project: `buildIosXcodeProject`) |
| Mac Native app (AOT-compiled, same pipeline as iOS) | Cloud, **or** locally as an Xcode project via `mac-source` | `mvn package -Dcodename1.platform=ios -Dcodename1.buildTarget=mac-os-x-native` (cloud) or `…-Dcodename1.buildTarget=mac-source` (local Xcode project) | `./gradlew buildMacNative` |
| Native Windows `.exe` (`win32`, ParparVM → clang-cl, no JVM) | Cloud (Linux build server cross-compiles); **also** locally on Windows, or as a project via `windows-source` | `mvn -pl common package -Dcodename1.platform=windows -Dcodename1.buildTarget=windows-device` (cloud) or `…-Dcodename1.buildTarget=local-windows-device` (local). A regular build returns x64 + arm64 release exes; add the `windows.debug` build hint for a single x64 debug exe. | `./gradlew buildWindowsDevice` |
| JavaScript / web bundle | Local (ParparVM to JavaScript translator, available to all users). Cloud builds use ParparVM by default and accept `javascript.port=teavm` as a compatibility fallback. | `mvn package -Dcodename1.platform=javascript -Dcodename1.buildTarget=local-javascript` | `./gradlew buildJavascriptLocal` (cloud: `buildJavascript`) |

Any target without its own Gradle task (`linux-desktop`, `mac-source`, `local-windows-device`, ...) is `./gradlew cn1Build -Pcodename1.platform=<platform> -Pcodename1.buildTarget=<target>`.

The two big "local-only" outputs are the **simulator** and **tests** — those are everything you need for ordinary development and CI feedback loops. You only invoke the cloud builds when you want a deployable native artifact.

## Required JDKs

| Task | JDK |
| --- | --- |
| Compiling the `common` module | JDK 17+ as `JAVA_HOME` |
| Running `cn1:run` / `cn1:debug` (the simulator) | **JDK 17–25** (CN1 plugin aborts on older JDKs with a friendly error) |
| Cross-compiling for Android **locally with Gradle 8** | The same JDK 17+ already used as `JAVA_HOME` is reused automatically; you only need to set `JAVA17_HOME` if Maven is running on an older JVM |
| Cross-compiling for iOS locally (`ios-source`) | macOS only — see Xcode prerequisites below |
| Cloud builds (any target) | None — the cloud server holds the toolchain. Local `JAVA_HOME` only runs Maven or Gradle. |

`codename1.arg.java.version=17` in `codenameone_settings.properties` selects the **build server's** JDK 17 toolchain. Keep it set even when you upgrade your local JDK (21, 25, …) — the local JDK only runs Maven and the simulator; the property routes the cloud-build target.

## Maven goal cheat sheet

All goals come from the `codenameone-maven-plugin` and live under the `cn1:` prefix. Run them from the project root unless noted.

```bash
# --- Local-only ---

# Desktop simulator (live, with hot CSS reload). No cloud, no credentials.
mvn -pl common cn1:run

# Debug from your IDE (attaches to JDWP).
mvn -pl common cn1:debug

# Hot reload of edited Java code (HotSwap, not full app restart) — see
# "Hot reload" below. Pick the mode from the simulator's Hot Reload menu.

# Run the CN1 test runner (NOT surefire). Runs inside the simulator JVM.
mvn -pl common cn1:test

# Compile CSS into theme.res without running the app. Process-resources phase.
mvn -pl common compile

# Generate stubs for any com.codename1.system.NativeInterface in common/
# (one per platform under android/, ios/, javase/, javascript/; the directory is
# created when needed, and is built from common/ when it has no pom.xml).
mvn -pl common cn1:generate-native-interfaces

# Generate a typed REST client from an OpenAPI 3.x spec. Writes
# `@Mapped` records (Java 17+) or classes (Java 8) per schema plus one
# `@RestClient`-annotated interface per OpenAPI tag into common/src/main/java
# at <basePackage>. The annotation processors run during the next compile
# and emit the wire impls into common/target/generated-sources -- the
# project source stays clean.
mvn -pl common cn1:generate-openapi \
  -Dcn1.openapi.spec=petstore.json \
  -Dcn1.openapi.basePackage=com.example.petstore

# Generate a typed gRPC-Web client from a .proto. Writes @ProtoMessage models
# (+ @ProtoEnum) and one @GrpcClient interface per service. Same processor
# pipeline as above. See references/api-clients.md.
mvn -pl common cn1:generate-grpc \
  -Dcn1.grpc.proto=catalog.proto \
  -Dcn1.grpc.basePackage=com.example.catalog

# Generate a typed GraphQL client from a schema (+ optional named operations).
# Writes @Mapped models, schema enums, and a @GraphQLClient interface with
# @Query/@Mutation/@Subscription methods. With an operations file the generated
# methods/response models are precise; without one it falls back to a
# bounded-depth (cn1.graphql.maxDepth, default 2) selection set per root field.
mvn -pl common cn1:generate-graphql \
  -Dcn1.graphql.schema=schema.graphqls \
  -Dcn1.graphql.operations=operations.graphql \
  -Dcn1.graphql.basePackage=com.example.catalog \
  -Dcn1.graphql.clientName=CatalogGraphApi

# --- Cloud builds (need a Codename One account; some need Enterprise tier) ---

# Native iOS app (.ipa). Cloud-built.
mvn package -Dcodename1.platform=ios -Dcodename1.buildTarget=ios-device

# Local Xcode project, no cloud. See Xcode prerequisites below.
# -Dopen=false: generate the sources without launching Xcode (see below).
mvn package -Dcodename1.platform=ios -Dcodename1.buildTarget=ios-source -Dopen=false

# Native Mac app (AOT-compiled, shares the iOS pipeline so the Mac slice
# is rendered + compiled the same way as the iOS one). Cloud-built.
mvn package -Dcodename1.platform=ios -Dcodename1.buildTarget=mac-os-x-native

# Local Xcode project for the Mac slice. Open the project in Xcode and
# select the Mac Catalyst destination to run.
mvn package -Dcodename1.platform=ios -Dcodename1.buildTarget=mac-source -Dopen=false

# Native Android APK/AAB. Cloud-built by default.
mvn package -Dcodename1.platform=android -Dcodename1.buildTarget=android-device

# JavaScript / web bundle. Built locally via the ParparVM to JavaScript translator.
# Append -Dcodename1.buildTarget=javascript instead to use the cloud builder.
mvn package -Dcodename1.platform=javascript -Dcodename1.buildTarget=local-javascript

# Standalone Mac / Windows / Linux desktop app. Cloud-built.
mvn package -Dcodename1.platform=javase -Dcodename1.buildTarget=mac-os-x-desktop
mvn package -Dcodename1.platform=javase -Dcodename1.buildTarget=windows-desktop
mvn package -Dcodename1.platform=javase -Dcodename1.buildTarget=linux-desktop
```

## Gradle task cheat sheet

A Gradle project applies the `com.codenameone` plugin from `settings.gradle.kts`; its version there is the Codename One version. Run tasks from the project root (`.\gradlew.bat` on Windows). `./gradlew tasks` lists them all.

```bash
# --- Local-only ---
./gradlew run                      # the simulator, with hot CSS reload
./gradlew debug                    # the simulator, suspended until a debugger attaches on port 5005
./gradlew cn1Test                  # the CN1 test runner; ./gradlew test runs JUnit
./gradlew cn1Css                   # compile theme.css into theme.res without running the app
./gradlew generateNativeInterfaces # stubs under src/<platform>/<lang>/ for every NativeInterface
./gradlew buildJavascriptLocal     # web bundle, locally
./gradlew buildIosXcodeProject -Pcodename1.open=false     # local Xcode project (macOS)
./gradlew buildAndroidGradleProject -Pcodename1.open=false # local Android Studio project
./gradlew settings                 # Codename One Settings; also guibuilder, certificateWizard
./gradlew cn1Update                # move settings.gradle.kts to the latest Codename One

# --- Cloud builds ---
./gradlew buildIos                 # debug .ipa; buildIosRelease for the App Store
./gradlew buildAndroid
./gradlew buildJavascript
./gradlew buildMacNative
./gradlew buildMacDesktop          # buildWindowsDesktop, buildWindowsDevice, buildLinuxDevice
./gradlew cn1Build -Pcodename1.platform=javase -Pcodename1.buildTarget=linux-desktop   # any other target
```

A build hint can be overridden for one build with `-Pcodename1.arg.<hint>=<value>`. The OpenAPI / gRPC / GraphQL client generators above are Maven goals; there is no Gradle task for them yet.

## Hot reload — Java edits without restarting the simulator

The simulator (`cn1:run` / `cn1:debug`) supports three reload modes, picked from the **Hot Reload** menu in the simulator's window (the setting persists per-project in Java preferences):

| Mode | What it does | When to use |
| --- | --- | --- |
| **Disabled** (default) | No reload — restart `cn1:run` to pick up Java edits. CSS still live-reloads regardless. | Production-style runs. |
| **Reload Simulator** | A file watcher (`SourceChangeWatcher`) recompiles changed `.java` files in `src/main/java/` (`common/src/main/java/` under Maven) via the IDE's incremental compiler and triggers a simulator restart. The simulator keeps the same JVM but rebuilds the form stack. | The most reliable mode — works on any edit (new class, signature change, new field). |
| **Reload Current Form** | Requires the **HotswapAgent** JVM agent (set up via `cn1:debug` + an IDE that pushes class file redefinitions through JDWP) **plus** CodeRAD wiring on your forms. When a `.java` file is recompiled, the simulator calls `FormController.tryCloneAndReplaceCurrentForm()` and re-shows the current form on the patched class. | Fastest iteration for UI tweaks inside a single form — preserves global state and the navigation stack, only the visible form re-renders. Method-body edits work; adding fields or methods falls back to a full restart. |

Behind the scenes:

- **CSS reload** is always on. Edits to `src/main/css/theme.css` (`common/src/main/css/theme.css` under Maven) are watched and `theme.res` is regenerated + re-injected into the running simulator without restarting the JVM. This works in every mode.
- **Java reload (mode 2)** is driven by the standard JVM HotSwap protocol (`-agentlib:jdwp=...,redefinitions=true`) plus [HotswapAgent](https://github.com/HotswapProjects/HotswapAgent) for the deeper redefinitions (added/removed methods, new classes). The IDE compiles the `.java` to a `.class` and JDWP-pushes it; the simulator notices via a system property and re-clones the form.
- The watcher only sees files written by the IDE — running `mvn compile` from a separate shell doesn't trigger reload because the IDE's incremental compiler is what writes the `.class` to `target/classes/`.

Method-body edits feel instantaneous; structural edits cost a form rebuild but no JVM restart.

## Tests in CI/CD

For **logic, UI, and screenshot tests**, run `mvn -pl common cn1:test` or `./gradlew cn1Test` (the CN1 test runner). It executes inside a local JVM via the simulator, so CI/CD does not need a Codename One account, a build server, or platform tooling — any GitHub Actions runner with a JDK 17+ can run it. This is the right loop for fast feedback.

### Framebuffer requirement on headless Linux runners

The CN1 test runner boots the simulator's AWT/Swing-based JavaSE port, which needs a graphics environment. macOS and Windows runners ship one out of the box. **Linux runners (the common GitHub Actions `ubuntu-latest`) do not** — you must provide a virtual framebuffer via `xvfb-run`:

```yaml
# .github/workflows/test.yml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: 'temurin', java-version: '17' }
      - name: Run CN1 tests under a virtual framebuffer
        run: xvfb-run -a ./mvnw -pl common test-compile cn1:test
        # Gradle: run: xvfb-run -a ./gradlew cn1Test
```

`xvfb-run -a` automatically picks a free display number (`-a` = autodisplay). Without it the test JVM aborts with `java.awt.HeadlessException` or "Can't connect to X11 display".

On `macos-latest` / `windows-latest` runners just call `./mvnw -pl common test-compile cn1:test` (or `./gradlew cn1Test`) directly — no wrapper needed.

You only need the cloud build path when you want to **produce a native artifact** (.ipa / .apk / desktop installer / web bundle) — see the next section.

## Automated cloud builds for CI / LLM workflows

`-Dautomated=true` on a cloud `package` goal switches the build into non-interactive mode: no browser prompt, no credential dialog, build failure becomes a non-zero exit code, and `result.zip` is downloaded directly into `target/`.

```bash
mvn package -Dcodename1.platform=ios     -Dcodename1.buildTarget=ios-device     -Dautomated=true
mvn package -Dcodename1.platform=android -Dcodename1.buildTarget=android-device -Dautomated=true

# Gradle
./gradlew buildIos -Pautomated=true
./gradlew buildAndroid -Pautomated=true
```

This is the right tool **specifically for producing native artifacts in unattended pipelines** (release builds, nightly TestFlight uploads, LLM-driven builds that need to verify a target compiles). It is **not** needed for running tests — tests are local.

Credentials must already be set:

- Provide `-Duser=<email> -Dtoken=<api-token>` on the command line.
- Or run `mvn cn1:set-user-token -Duser=<email> -Dtoken=<token>` once on the build machine; credentials are then stored in Java preferences for the user.

> **Tier requirement**: `-Dautomated=true` and the API-token-based, non-interactive build flow require a **Codename One Enterprise** subscription. Free/community accounts can use the regular cloud build (which opens a browser for login) but not the unattended automated mode.

## Generating native projects without opening an IDE

The `*-source` targets (`ios-source`, `mac-source`, `android-source`, and the
`buildIosXcodeProject` / `buildAndroidGradleProject` goals and tasks) open the
generated project in Xcode or Android Studio when they finish. That is meant for
a person at the keyboard. **As an agent, always pass `-Dopen=false`** (Gradle:
`-Pcodename1.open=false`): every build you run would otherwise leave another IDE
window on the user's screen.

The build also skips opening on its own when it sees an agent or CI environment
(`CLAUDECODE`, `CODEX_SANDBOX`, `CURSOR_AGENT`, `GEMINI_CLI`, `AGENT`, `CI`), and
logs that it did. Do not rely on that: your tool may set none of them. Pass the
flag. To build the generated Xcode project headlessly, use `xcodebuild` on the
`.xcworkspace` (or `.xcodeproj`) under `ios/target/<finalName>-ios-source/` (the build logs the exact path);
for Android, run `./gradlew assembleDebug` inside the generated project.

## Local iOS builds (`ios-source`) prerequisites

**For an agent, or anyone without a Mac, a cloud build is the default:** it needs none of the table below and builds, signs and submits from any OS. See `cloud-agent.md`. Use `ios-source` only when the developer has a Mac and asks for a local Xcode project.

`-Dcodename1.buildTarget=ios-source` skips the build server and emits an Xcode project under `ios/target/<finalName>-ios-source/` (the build logs the exact path). You can open it in Xcode (or build it with `xcodebuild`) and produce an `.ipa` locally. Requirements:

| Requirement | Notes |
| --- | --- |
| macOS | Apple silicon or Intel; no other OS can build iOS apps. |
| Xcode | Latest stable from the App Store. If you intend to submit to the App Store, use the version Apple currently mandates. |
| Xcode command-line tools | `xcode-select --install`. Required for `xcodebuild` and the iOS Simulator. |
| CocoaPods | `sudo gem install cocoapods` if your project (or any cn1lib) declares `codename1.arg.ios.pods`. |
| Apple developer account + signing | Set `codename1.arg.ios.teamId=ABCDEF1234` in `codenameone_settings.properties` so the generated Xcode project signs with your team automatically. |
| Deployment target | Set `codename1.arg.ios.deployment_target=14.0` (or current minimum) to match Apple's accepted submission range. |

After the project is generated, you can also run `xcodebuild -workspace <App>.xcworkspace -scheme <App> -configuration Release archive` from CI to produce an archive without opening Xcode interactively.

## `codenameone_settings.properties` — the configuration source of truth

This file lives at `common/codenameone_settings.properties` in a Maven project and at the project root in a Gradle project. The most useful keys:

```properties
codename1.packageName=com.exg.mygame
codename1.mainName=MyGame
codename1.displayName=My App Name
codename1.arg.java.version=17                 # Required: routes the build to the Java 17 build server
codename1.arg.ios.includePush=false
codename1.kotlin=false
codename1.arg.android.xpermissions=...
codename1.arg.ios.deployment_target=14.0
codename1.arg.ios.teamId=ABCDEF1234
```

Anything prefixed `codename1.arg.<platform>.<key>` is forwarded to the build server. See [`build-hints.md`](build-hints.md) for the curated index of build hints. The complete reference is in the Codename One Developer Guide at <https://www.codenameone.com/developer-guide/>.

## Layout invariants

Paths below are Maven's; in a Gradle project drop the leading `common/` (and `common/target/` is `build/`).

- `common/src/main/css/theme.css` — **the** CSS file. Compiled to `common/target/classes/theme.res`.
- `common/src/main/l10n/messages*.properties` — i18n bundles. **MUST** live here (not in `src/main/resources`), or the CSS compiler will not bake them in.
- `common/src/main/java/<pkg>/<MainClass>.java` — entry point. Class name must match `codename1.mainName`.
- `common/src/main/resources/` — arbitrary runtime resources read at runtime via `Display.getInstance().getResourceAsStream("/file.json")`. **Important constraint**: the Codename One classloader keeps resources in a **flat namespace** — nested directories under `src/main/resources` are not supported by default. Drop files at the top level (e.g. `src/main/resources/data.json` → loaded as `/data.json`). If you must ship a deeper structure, package it inside a single zip resource and read entries with `ZipInputStream` on top of `getResourceAsStream`. See `references/java-api-subset.md` for IO patterns.
- `common/src/main/guibuilder/` — optional GUI builder XML (auto-generates Java).

## Common build errors and fixes

- **`Resources.getGlobalResources().getL10N(...)` returns null at runtime** → your bundles are under `common/src/main/resources/` instead of `common/src/main/l10n/`. Move them.
- **`Cannot find symbol class XxxView`** after using the GUI builder → run `mvn -pl common generate-sources` (Gradle: `./gradlew generateGuiSources`, which also runs before every compile) to regenerate.
- **`OutOfMemoryError` running `cn1:test`** → bump `<argLine>-Xmx2g</argLine>` in the surefire/cn1 plugin config in `common/pom.xml`.
- **Build server returns "build args invalid"** → check `codename1.arg.*` keys against [`build-hints.md`](build-hints.md) or the Developer Guide.
- **`Codename One Gradle projects compile for Java 17`** → a Gradle build script set a lower `release`; remove it. Java 8 projects need the Maven build.
- **`When using gradle 8, you must set the JAVA17_HOME environment variable`** for a local Android build → only happens when Maven itself is running on a JDK older than 17. Re-launch Maven with a JDK 17+ `JAVA_HOME` and the builder reuses it automatically.
- **`-Dautomated=true` exits 0 even though the build failed** → make sure you're on a recent `cn1.plugin.version`; older versions of the plugin swallowed errors.

## The build client jar

The build server protocol is driven by `CodeNameOneBuildClient.jar`. The Codename One Maven (and Gradle) plugin places it under `~/.codenameone/CodeNameOneBuildClient.jar` automatically the first time you run a `cn1:build` / `package` goal. If it ever goes missing, download the canonical copy:

<https://github.com/codenameone/CodenameOne/raw/refs/heads/master/maven/CodeNameOneBuildClient.jar>

Put it at `~/.codenameone/CodeNameOneBuildClient.jar`.

## Reference links

- Codename One Developer Guide: <https://www.codenameone.com/developer-guide/>
- JavaDoc: <https://www.codenameone.com/javadoc/>
- Maven plugin manual: <https://shannah.github.io/codenameone-maven-manual/>
- Build hints curated index: [`build-hints.md`](build-hints.md)
- Java API subset, IO, networking: [`java-api-subset.md`](java-api-subset.md)
